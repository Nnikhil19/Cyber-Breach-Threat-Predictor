import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, ConfusionMatrixDisplay

import matplotlib.pyplot as plt
from tabulate import tabulate

# --- Configuration ---
DATA_FILE = r'c:\Users\sinha\Downloads\Research\data_breach_dataset.csv'
HIGH_IMPACT_THRESHOLD = 500_000

FEATURE_COLUMNS = [
    'event_year',       # Temporal
    'breach_type',      # Categorical
    'event_state',      # Categorical
    'hq_state'          # Categorical
]
TARGET_COLUMN = 'is_high_impact'

# --- 1. Load Data ---
try:
    print(f"Loading data from {DATA_FILE}...")
    df = pd.read_csv(DATA_FILE, delimiter=',', encoding='latin1')
    print("Data loaded successfully.")
except FileNotFoundError:
    print(f"Error: File not found at {DATA_FILE}")
    exit()
except UnicodeDecodeError as e:
    print(f"Error: Unable to decode the file. {e}")
    exit()

# --- 2. Data Cleaning and Target Variable Creation ---
print("Cleaning data and creating target variable...")

if 'breach_size' not in df.columns:
    print("Error: 'breach_size' column is missing.")
    exit()

df['breach_size'] = pd.to_numeric(df['breach_size'], errors='coerce').fillna(0)
df[TARGET_COLUMN] = (df['breach_size'] >= HIGH_IMPACT_THRESHOLD).astype(int)

X = df[FEATURE_COLUMNS]
y = df[TARGET_COLUMN]

# --- 3. Preprocessing ---
print("\nSetting up preprocessing steps...")

numerical_features = X.select_dtypes(include=np.number).columns.tolist()
categorical_features = X.select_dtypes(exclude=np.number).columns.tolist()

numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='Missing')),
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ],
    remainder='passthrough'
)

# --- 4. Train-Test Split ---
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# --- 5. Model Training ---
model_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(
        n_estimators=100,
        random_state=42,
        class_weight='balanced'
    ))
])

model_pipeline.fit(X_train, y_train)
print("Model training complete.")

# --- 6. Prediction and Evaluation ---
y_pred = model_pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"\nModel Accuracy: {accuracy:.4f}")

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Low Impact', 'High Impact']))

print("\nConfusion Matrix:")
cm = confusion_matrix(y_test, y_pred)
print(cm)

# Display confusion matrix in a GUI tab
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Low Impact', 'High Impact'])
disp.plot(cmap=plt.cm.Blues)
plt.title('Confusion Matrix - High Impact Breach Prediction')
plt.show()

# --- 7. User Input for Prediction ---
print("\nEnter new data in the following format:")
print("event_year,breach_type,event_state,hq_state")
print("Example: 2015,HACK,California,Texas")

while True:
    user_input = input("\nEnter data (or type 'exit' to quit): ").strip()
    if user_input.lower() == 'exit':
        print("Exiting...")
        break

    try:
        # Parse user input
        input_data = [x.strip() for x in user_input.split(',')]
        if len(input_data) != len(FEATURE_COLUMNS):
            raise ValueError(f"Invalid input format. Expected {len(FEATURE_COLUMNS)} values separated by commas.")

        # Create a DataFrame for the input
        input_df = pd.DataFrame([input_data], columns=FEATURE_COLUMNS)

        # Preprocess and predict
        prediction_proba = model_pipeline.predict_proba(input_df)[0][1] * 100
        prediction = model_pipeline.predict(input_df)[0]

        print(f"\nPrediction: {'High Impact' if prediction == 1 else 'Low Impact'}")
        print(f"Likelihood of being a major breach: {prediction_proba:.2f}%")

        # Feature importance explanation
        rf_model = model_pipeline.named_steps['classifier']
        onehot_encoder = model_pipeline.named_steps['preprocessor'].named_transformers_['cat'].named_steps['onehot']
        onehot_feature_names = onehot_encoder.get_feature_names_out(categorical_features)
        processed_feature_names = numerical_features + onehot_feature_names.tolist()
        importances = rf_model.feature_importances_

        feature_importance_df = pd.DataFrame({
            'Feature': processed_feature_names,
            'Importance': importances
        }).sort_values(by='Importance', ascending=False)

        print("\nTop Contributing Features:")
        print(tabulate(feature_importance_df.head(5), headers='keys', tablefmt='grid'))

    except ValueError as ve:
        print(f"Input Error: {ve}")
    except Exception as e:
        print(f"Error processing input: {e}")
